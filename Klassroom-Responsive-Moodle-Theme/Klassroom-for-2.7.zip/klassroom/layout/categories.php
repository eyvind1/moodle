<!-- Start Category Section-->
<?php global $PAGE,$theme;
   if (!empty($PAGE->theme->settings->enablecategoryimage)) { ?>
<div class="customcategories row-fluid">
</div>
<?php }else { ?>
<div class="defaultcategories row-fluid">
   <div class="container-fluid">
   </div>
</div>
<?php } ?>
<!-- End Category Section-->