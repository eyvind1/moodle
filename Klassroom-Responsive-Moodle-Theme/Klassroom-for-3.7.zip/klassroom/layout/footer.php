<script type="text/javascript">
    var categorytagline = "<?= $categorytagline ?>";
    var allcoursestagline = "<?= $allcoursestagline ?>";
    var mycoursestagline = "<?= $mycoursestagline ?>";
    var internalbannertagline = "<?= $internalbannertagline ?>";
</script>

